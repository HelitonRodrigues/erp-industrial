package br.com.silicate.avisos;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.util.TypedValue;
import android.text.InputFilter;
import android.text.InputType;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/** Tela do app: estado, linhas agora, abrir o ERP, escolher avisos e testar sons. Feita em código (sem XML). */
public class MainActivity extends Activity {
    static final String EXTRA_OK = "ok";
    static final int NAVY = 0xFF042D4D, LIME = 0xFFC9FF64, FUNDO = 0xFFF4F6F8, CINZA = 0xFF64748B;

    private final Handler h = new Handler(Looper.getMainLooper());
    private final OkHttpClient http = new OkHttpClient();
    private TextView tvEstado;
    private LinearLayout boxLinhas, boxAlertas, boxTvs;
    private TextView tvTvEstado;
    private Button btTvParar, btTvAgora;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(NAVY);
        montarTela();
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
        ligarServico(null, null);
        tratarIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        tratarIntent(i);
    }

    private void tratarIntent(Intent i) {
        if (i != null && i.getBooleanExtra(EXTRA_OK, false)) ligarServico(AvisoService.ACAO_OK, null);   // abriu pelo aviso = "vi"
    }

    @Override
    protected void onResume() {
        super.onResume();
        montarAlertas();
        carregarLinhas();
        h.post(relogio);
    }

    @Override
    protected void onPause() {
        h.removeCallbacks(relogio);
        super.onPause();
    }

    @Override
    public void onRequestPermissionsResult(int rc, String[] p, int[] r) {
        super.onRequestPermissionsResult(rc, p, r);
        montarAlertas();
    }

    private final Runnable relogio = new Runnable() {
        @Override public void run() {
            boolean ok = AvisoService.conectado;
            tvEstado.setText((ok ? "🟢 " : "🔴 ") + AvisoService.estado);
            tvEstado.setBackground(caixa(ok ? 0xFFDCFCE7 : 0xFFFEE2E2, 14));
            tvEstado.setTextColor(ok ? 0xFF166534 : 0xFF991B1B);
            String e = TvDlna.estado;
            tvTvEstado.setText(e == null || e.isEmpty() ? "Nenhuma TV recebendo o painel agora." : e);
            btTvParar.setVisibility(TvDlna.ativo ? android.view.View.VISIBLE : android.view.View.GONE);
            btTvAgora.setVisibility(TvDlna.ativo ? android.view.View.VISIBLE : android.view.View.GONE);
            h.postDelayed(this, 2_000);
        }
    };

    private void ligarServico(String acao, String status) {
        Intent i = new Intent(this, AvisoService.class);
        if (acao != null) i.setAction(acao);
        if (status != null) i.putExtra(AvisoService.EXTRA_STATUS, status);
        try { startForegroundService(i); }
        catch (Exception e) { android.util.Log.e(AvisoService.TAG, "não ligou o serviço", e); }
    }

    // ── tela ────────────────────────────────────────────────────────────────
    private void montarTela() {
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(FUNDO);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(16), dp(16), dp(16), dp(32));
        sv.addView(col);

        LinearLayout topo = new LinearLayout(this);
        topo.setOrientation(LinearLayout.VERTICAL);
        topo.setPadding(dp(18), dp(18), dp(18), dp(18));
        topo.setBackground(caixa(NAVY, 16));
        topo.addView(texto("Avisos das Linhas", 24, Color.WHITE, true));
        topo.addView(texto("Grupo Silicate — toca o som do status mesmo com o celular no silencioso", 13, 0xFFCBD5E1, false));
        col.addView(topo, mlp(0, 0, 0, 12));

        tvEstado = texto("…", 16, CINZA, true);
        tvEstado.setPadding(dp(14), dp(12), dp(14), dp(12));
        col.addView(tvEstado, mlp(0, 0, 0, 12));

        boxAlertas = new LinearLayout(this);
        boxAlertas.setOrientation(LinearLayout.VERTICAL);
        col.addView(boxAlertas);

        Button erp = botao("ABRIR O ERP", NAVY, LIME, 20);
        erp.setOnClickListener(v -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(Cfg.ERP))));
        col.addView(erp, mlp(0, 0, 0, 16));

        col.addView(titulo("🏭 Como as linhas estão agora"));
        boxLinhas = new LinearLayout(this);
        boxLinhas.setOrientation(LinearLayout.VERTICAL);
        col.addView(boxLinhas, mlp(0, 0, 0, 16));

        col.addView(titulo("🔔 Quais avisos tocam neste celular"));
        SharedPreferences p = getSharedPreferences(Cfg.PREFS, MODE_PRIVATE);
        for (Status s : Status.values()) {
            CheckBox cb = new CheckBox(this);
            cb.setText(s.icone + "  " + s.nome);
            cb.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
            cb.setTypeface(Typeface.DEFAULT_BOLD);
            cb.setTextColor(0xFF0F172A);
            cb.setChecked(p.getBoolean(s.chavePref(), true));
            cb.setPadding(dp(8), dp(10), dp(8), dp(10));
            cb.setBackground(caixaBorda(Color.WHITE, s.cor));
            cb.setOnCheckedChangeListener((v, marcado) -> p.edit().putBoolean(s.chavePref(), marcado).apply());
            col.addView(cb, mlp(0, 0, 0, 8));
        }

        col.addView(titulo("🔊 Testar os sons"));
        LinearLayout grade = new LinearLayout(this);
        grade.setOrientation(LinearLayout.VERTICAL);
        for (Status s : Status.values()) {
            Button t = botao("▶  " + s.nome.toUpperCase(), s.cor, Color.WHITE, 17);
            t.setOnClickListener(v -> ligarServico(AvisoService.ACAO_TESTE, s.nome));
            grade.addView(t, mlp(0, 0, 0, 8));
        }
        col.addView(grade);
        Button parar = botao("⏹  PARAR O SOM", 0xFF334155, Color.WHITE, 16);
        parar.setOnClickListener(v -> ligarServico(AvisoService.ACAO_OK, null));
        col.addView(parar, mlp(0, 4, 0, 16));

        montarTv(col);

        TextView rodape = texto("O app fica ligado sozinho, inclusive depois de reiniciar o celular. O ícone na barra de cima mostra que ele está escutando.", 12, CINZA, false);
        col.addView(rodape);
        setContentView(sv);
    }

    /** 📺 Painel de Metas numa TV por DLNA (Samsung, LG… "compartilhar mídia"). */
    private void montarTv(LinearLayout col) {
        col.addView(titulo("📺 Mostrar o Painel de Metas numa TV"));
        TextView ex = texto("Para TVs que não têm Chromecast (Samsung, LG, Philips…). O celular tira uma foto do painel e manda para a TV pelo Wi-Fi a cada 5 minutos. O celular tem que ficar ligado e no MESMO Wi-Fi da TV.", 13, CINZA, false);
        col.addView(ex, mlp(0, 0, 0, 8));

        SharedPreferences p = getSharedPreferences(Cfg.PREFS, MODE_PRIVATE);
        TextView lbl = texto("Código da TV (no ERP: Painel de Metas → 📺 Passar para a TV):", 13, 0xFF0F172A, true);
        col.addView(lbl, mlp(0, 0, 0, 4));
        EditText cod = new EditText(this);
        cod.setText(p.getString(TvDlna.PREF_CODIGO, ""));
        cod.setHint("ex.: WRRK GTVJ");
        cod.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        cod.setTypeface(Typeface.DEFAULT_BOLD);
        cod.setSingleLine(true);
        cod.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        cod.setFilters(new InputFilter[]{new InputFilter.AllCaps(), new InputFilter.LengthFilter(12)});
        cod.setBackground(caixaBorda(Color.WHITE, 0xFFCBD5E1));
        cod.setPadding(dp(14), dp(10), dp(14), dp(10));
        col.addView(cod, mlp(0, 0, 0, 8));

        Button procurar = botao("🔍  PROCURAR TV NA REDE", NAVY, LIME, 18);
        col.addView(procurar, mlp(0, 0, 0, 8));
        boxTvs = new LinearLayout(this);
        boxTvs.setOrientation(LinearLayout.VERTICAL);
        col.addView(boxTvs);

        tvTvEstado = texto("", 14, 0xFF0F172A, true);
        tvTvEstado.setPadding(dp(12), dp(10), dp(12), dp(10));
        tvTvEstado.setBackground(caixa(0xFFE2E8F0, 12));
        col.addView(tvTvEstado, mlp(0, 4, 0, 8));

        btTvAgora = botao("🔄  MANDAR DE NOVO AGORA", 0xFF2563EB, Color.WHITE, 15);
        btTvAgora.setOnClickListener(v -> ligarServico(AvisoService.ACAO_TV_AGORA, null));
        col.addView(btTvAgora, mlp(0, 0, 0, 8));
        btTvParar = botao("⏹  PARAR DE MANDAR PARA A TV", 0xFFDC2626, Color.WHITE, 15);
        btTvParar.setOnClickListener(v -> ligarServico(AvisoService.ACAO_TV_PARAR, null));
        col.addView(btTvParar, mlp(0, 0, 0, 16));

        procurar.setOnClickListener(v -> {
            String c = cod.getText().toString().toUpperCase().replaceAll("[^A-Z0-9]", "");
            if (c.length() < 6) { cod.setError("Digite o código da TV"); return; }
            p.edit().putString(TvDlna.PREF_CODIGO, c).apply();
            boxTvs.removeAllViews();
            boxTvs.addView(texto("Procurando TVs no Wi-Fi… (uns 5 segundos)", 14, CINZA, true), mlp(0, 0, 0, 8));
            procurar.setEnabled(false);
            new Thread(() -> {
                List<TvDlna.Tv> tvs = null; String erro = null;
                try { tvs = TvDlna.procurar(MainActivity.this); } catch (Exception e) { erro = e.getMessage(); }
                final List<TvDlna.Tv> achadas = tvs; final String falha = erro;
                h.post(() -> { procurar.setEnabled(true); mostrarTvs(achadas, falha); });
            }, "procurar-tv").start();
        });
    }

    private void mostrarTvs(List<TvDlna.Tv> tvs, String erro) {
        boxTvs.removeAllViews();
        if (erro != null) { boxTvs.addView(texto("⚠️ Erro ao procurar: " + erro, 14, 0xFF991B1B, true), mlp(0, 0, 0, 8)); return; }
        if (tvs == null || tvs.isEmpty()) {
            boxTvs.addView(texto("Nenhuma TV encontrada. Confira: TV ligada, no mesmo Wi-Fi do celular e com \"compartilhar mídia / DLNA\" ligado nas configurações da TV.", 14, 0xFF991B1B, true), mlp(0, 0, 0, 8));
            return;
        }
        boxTvs.addView(texto("Toque na TV:", 14, 0xFF0F172A, true), mlp(0, 0, 0, 6));
        for (TvDlna.Tv tv : tvs) {
            Button b = botao("📺  " + tv.nome, 0xFF16A34A, Color.WHITE, 17);
            b.setOnClickListener(v -> {
                Intent i = new Intent(this, AvisoService.class).setAction(AvisoService.ACAO_TV_INICIAR)
                        .putExtra(AvisoService.EXTRA_TV_NOME, tv.nome).putExtra(AvisoService.EXTRA_TV_CONTROLE, tv.controle);
                try { startForegroundService(i); } catch (Exception e) { android.util.Log.e(AvisoService.TAG, "tv", e); }
                boxTvs.removeAllViews();
            });
            boxTvs.addView(b, mlp(0, 0, 0, 8));
        }
    }

    /** Avisos que dependem de permissão: aparecem só se faltar algo. */
    private void montarAlertas() {
        boxAlertas.removeAllViews();
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (!pm.isIgnoringBatteryOptimizations(getPackageName())) {
            Button b = botao("⚡ TOQUE AQUI e depois em PERMITIR\npara o celular não desligar os avisos", 0xFFFACC15, 0xFF422006, 15);
            b.setOnClickListener(v -> {
                try {
                    startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName())));
                } catch (Exception e) {
                    startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
                }
            });
            boxAlertas.addView(b, mlp(0, 0, 0, 12));
        }
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (!nm.areNotificationsEnabled()) {
            Button b = botao("🔕 As notificações estão bloqueadas.\nTOQUE AQUI e ative", 0xFFFEE2E2, 0xFF991B1B, 15);
            b.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName())));
            boxAlertas.addView(b, mlp(0, 0, 0, 12));
        }
    }

    private void carregarLinhas() {
        Request r = new Request.Builder()
                .url(Cfg.SUPABASE + "/rest/v1/rpc/linhas_status_atual_publico")
                .header("apikey", Cfg.ANON)
                .header("Authorization", "Bearer " + Cfg.ANON)
                .post(RequestBody.create("{}", MediaType.get("application/json")))
                .build();
        http.newCall(r).enqueue(new Callback() {
            @Override public void onFailure(Call c, IOException e) {
                h.post(() -> mostrarLinhas(null));
            }
            @Override public void onResponse(Call c, Response resp) {
                String t = null;
                try { if (resp.isSuccessful() && resp.body() != null) t = resp.body().string(); } catch (IOException ignored) { /* mostra erro */ }
                resp.close();
                final String txt = t;
                h.post(() -> mostrarLinhas(txt));
            }
        });
    }

    private void mostrarLinhas(String json) {
        boxLinhas.removeAllViews();
        if (json == null) { boxLinhas.addView(texto("Sem internet agora.", 14, CINZA, false)); return; }
        try {
            JSONArray arr = new JSONArray(json);
            if (arr.length() == 0) boxLinhas.addView(texto("Nenhuma análise ainda.", 14, CINZA, false));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                Status s = Status.de(o.optString("status"));
                int cor = s != null ? s.cor : CINZA;
                String det = o.isNull("produto") ? "" : o.optString("produto");
                if (!o.isNull("hora") && o.optString("hora").length() >= 5) det += (det.isEmpty() ? "" : " · ") + o.optString("hora").substring(0, 5);
                TextView tv = texto(o.optString("linha") + "   " + (s != null ? s.icone + " " + s.nome.toUpperCase() : o.optString("status"))
                        + (det.isEmpty() ? "" : "\n" + det), 16, Color.WHITE, true);
                tv.setPadding(dp(14), dp(12), dp(14), dp(12));
                tv.setBackground(caixa(cor, 12));
                boxLinhas.addView(tv, mlp(0, 0, 0, 8));
            }
        } catch (Exception e) {
            boxLinhas.addView(texto("Não foi possível ler as linhas.", 14, CINZA, false));
        }
    }

    // ── ajudantes de layout ─────────────────────────────────────────────────
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private LinearLayout.LayoutParams mlp(int l, int t, int r, int b) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(l), dp(t), dp(r), dp(b));
        return lp;
    }

    private TextView texto(String s, int sp, int cor, boolean negrito) {
        TextView tv = new TextView(this);
        tv.setText(s);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        tv.setTextColor(cor);
        if (negrito) tv.setTypeface(Typeface.DEFAULT_BOLD);
        return tv;
    }

    private TextView titulo(String s) {
        TextView tv = texto(s, 14, NAVY, true);
        tv.setPadding(0, dp(4), 0, dp(8));
        return tv;
    }

    private Button botao(String s, int fundo, int cor, int sp) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextColor(cor);
        b.setBackground(caixa(fundo, 14));
        b.setPadding(dp(14), dp(16), dp(14), dp(16));
        b.setGravity(Gravity.CENTER);
        b.setStateListAnimator(null);
        return b;
    }

    private GradientDrawable caixa(int cor, int raio) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(cor);
        g.setCornerRadius(dp(raio));
        return g;
    }

    private GradientDrawable caixaBorda(int cor, int borda) {
        GradientDrawable g = caixa(cor, 12);
        g.setStroke(dp(3), borda);
        return g;
    }
}
