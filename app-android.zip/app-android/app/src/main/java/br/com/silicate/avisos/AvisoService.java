package br.com.silicate.avisos;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.drawable.Icon;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.time.OffsetDateTime;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;

/**
 * Fica ligado o tempo todo (serviço em primeiro plano) escutando o canal
 * "linhas-status" do Supabase. Cada mudança → notificação + som do status
 * no volume de ALARME (toca mesmo no silencioso). Parada repete a cada 10 s
 * até tocar em "OK, VI" (máx. 5 min).
 * Reserva: confere o banco a cada 30 s (RPC linhas_status_publico) — se o
 * canal cair, nada se perde.
 */
public class AvisoService extends Service {
    static final String TAG = "Avisos";
    static final String ACAO_OK = "br.com.silicate.avisos.OK";
    static final String ACAO_TESTE = "br.com.silicate.avisos.TESTE";
    static final String EXTRA_STATUS = "status";
    static final String ACAO_TV_INICIAR = "br.com.silicate.avisos.TV_INICIAR";
    static final String ACAO_TV_PARAR = "br.com.silicate.avisos.TV_PARAR";
    static final String ACAO_TV_AGORA = "br.com.silicate.avisos.TV_AGORA";
    static final String EXTRA_TV_NOME = "tv_nome", EXTRA_TV_CONTROLE = "tv_controle";
    static final String CANAL_FIXO = "monitor";
    static final int ID_FIXO = 1;

    static final long POLL_MS = 30_000, HEARTBEAT_MS = 25_000, REPETE_MS = 10_000, REPETE_MAX_MS = 5 * 60_000;
    static final long VALIDADE_MS = 15 * 60_000;

    /** Lido pela tela principal. */
    static volatile String estado = "Iniciando…";
    static volatile boolean conectado = false;
    static volatile long ultimaConferencia = 0;

    private final Handler h = new Handler(Looper.getMainLooper());
    private OkHttpClient http;
    private WebSocket ws;
    private int geracao = 0, ref = 1;
    private long ultimoId = -1;
    private boolean buscando = false;
    private long esperaReconectar = 3_000;
    private PowerManager.WakeLock wl;
    private MediaPlayer mp;
    private Status repetindo = null;
    private long repeteDesde = 0;
    private int volumeAntes = -1;
    private TvDlna tv;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        criarCanais();
        Notification n = notifFixa("Ligando…");
        if (Build.VERSION.SDK_INT >= 34) startForeground(ID_FIXO, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(ID_FIXO, n);

        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AvisosSilicate:escuta");
        wl.setReferenceCounted(false);
        wl.acquire();

        http = new OkHttpClient.Builder()
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(20, TimeUnit.SECONDS)
                .pingInterval(20, TimeUnit.SECONDS)
                .build();
        conectar();
        h.postDelayed(poll, 1_000);
        tv = new TvDlna(this);
        tv.retomarSeEstavaLigado();      // estava passando na TV antes de reiniciar? volta sozinho
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String a = intent != null ? intent.getAction() : null;
        if (ACAO_OK.equals(a)) {
            pararAlarme();
        } else if (ACAO_TV_INICIAR.equals(a)) {
            tv.iniciar(intent.getStringExtra(EXTRA_TV_NOME), intent.getStringExtra(EXTRA_TV_CONTROLE));
        } else if (ACAO_TV_PARAR.equals(a)) {
            tv.parar(true);
        } else if (ACAO_TV_AGORA.equals(a)) {
            tv.mandarAgora();
        } else if (ACAO_TESTE.equals(a)) {
            Status s = Status.de(intent.getStringExtra(EXTRA_STATUS));
            if (s != null) tocar(s);
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        h.removeCallbacksAndMessages(null);
        geracao++;
        if (ws != null) ws.close(1000, "fim");
        pararAlarme();
        if (tv != null) tv.parar(false);
        if (wl != null && wl.isHeld()) wl.release();
        conectado = false;
        estado = "Desligado";
        super.onDestroy();
    }

    // ── canal ao vivo (Supabase Realtime, protocolo Phoenix) ───────────────
    private void conectar() {
        final int g = ++geracao;
        if (ws != null) { try { ws.cancel(); } catch (Exception ignored) { /* já fechado */ } }
        ws = http.newWebSocket(new Request.Builder().url(Cfg.WS).build(), new WebSocketListener() {
            @Override public void onOpen(WebSocket s, Response r) {
                h.post(() -> {
                    if (g != geracao) return;
                    String join = "{\"topic\":\"realtime:linhas-status\",\"event\":\"phx_join\",\"ref\":\"" + (ref++) + "\",\"join_ref\":\"1\","
                            + "\"payload\":{\"config\":{\"broadcast\":{\"ack\":false,\"self\":false},\"presence\":{\"key\":\"\"},"
                            + "\"postgres_changes\":[],\"private\":false},\"access_token\":\"" + Cfg.ANON + "\"}}";
                    s.send(join);
                    conectado = true;
                    esperaReconectar = 3_000;
                    atualizarEstado("Escutando as linhas ✓");
                    buscar();                                   // pega o que mudou enquanto estava fora
                    h.postDelayed(() -> heartbeat(g), HEARTBEAT_MS);
                });
            }
            @Override public void onMessage(WebSocket s, String texto) {
                try {
                    JSONObject m = new JSONObject(texto);
                    if ("broadcast".equals(m.optString("event"))) h.post(AvisoService.this::buscar);
                } catch (Exception e) { Log.w(TAG, "mensagem estranha: " + texto); }
            }
            @Override public void onClosing(WebSocket s, int code, String reason) { s.close(1000, null); }
            @Override public void onClosed(WebSocket s, int code, String reason) { h.post(() -> caiu(g, "fechou " + code)); }
            @Override public void onFailure(WebSocket s, Throwable t, Response r) { h.post(() -> caiu(g, String.valueOf(t))); }
        });
    }

    private void heartbeat(int g) {
        if (g != geracao || ws == null) return;
        ws.send("{\"topic\":\"phoenix\",\"event\":\"heartbeat\",\"payload\":{},\"ref\":\"" + (ref++) + "\"}");
        h.postDelayed(() -> heartbeat(g), HEARTBEAT_MS);
    }

    private void caiu(int g, String motivo) {
        if (g != geracao) return;
        Log.w(TAG, "canal caiu: " + motivo);
        conectado = false;
        atualizarEstado("Sem conexão — tentando de novo…");
        long espera = esperaReconectar;
        esperaReconectar = Math.min(esperaReconectar * 2, 60_000);
        h.postDelayed(() -> { if (g == geracao) conectar(); }, espera);
    }

    // ── conferência no banco (reserva) ─────────────────────────────────────
    private final Runnable poll = new Runnable() {
        @Override public void run() {
            buscar();
            h.postDelayed(this, POLL_MS);
        }
    };

    private void buscar() {
        if (buscando) return;
        buscando = true;
        final boolean primeira = ultimoId < 0;
        String corpo = "{\"p_desde_id\":" + Math.max(ultimoId, 0) + "}";
        Request r = new Request.Builder()
                .url(Cfg.SUPABASE + "/rest/v1/rpc/linhas_status_publico")
                .header("apikey", Cfg.ANON)
                .header("Authorization", "Bearer " + Cfg.ANON)
                .post(RequestBody.create(corpo, MediaType.get("application/json")))
                .build();
        http.newCall(r).enqueue(new Callback() {
            @Override public void onFailure(Call c, IOException e) {
                h.post(() -> { buscando = false; if (!conectado) atualizarEstado("Sem internet — tentando de novo…"); });
            }
            @Override public void onResponse(Call c, Response resp) {
                String txt = null;
                try { txt = resp.body() != null ? resp.body().string() : null; } catch (IOException ignored) { /* trata abaixo */ }
                final int code = resp.code();
                resp.close();
                final String t = txt;
                h.post(() -> {
                    buscando = false;
                    if (code != 200 || t == null) { Log.w(TAG, "rpc " + code + ": " + t); return; }
                    ultimaConferencia = System.currentTimeMillis();
                    processar(t, primeira);
                });
            }
        });
    }

    private void processar(String json, boolean primeira) {
        try {
            JSONArray arr = new JSONArray(json);
            long maior = Math.max(ultimoId, 0);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject e = arr.getJSONObject(i);
                long id = e.getLong("id");
                if (id <= ultimoId) continue;
                maior = Math.max(maior, id);
                if (primeira) continue;                       // ao ligar não toca o passado
                if (velho(e.optString("criado_em"))) continue;
                avisar(e);
            }
            ultimoId = maior;
        } catch (Exception ex) {
            Log.e(TAG, "resposta inválida", ex);
        }
    }

    private boolean velho(String iso) {
        try {
            return System.currentTimeMillis() - OffsetDateTime.parse(iso).toInstant().toEpochMilli() > VALIDADE_MS;
        } catch (Exception e) { return false; }
    }

    // ── aviso: notificação + som ────────────────────────────────────────────
    private void avisar(JSONObject e) {
        Status s = Status.de(e.optString("status_novo"));
        if (s == null) return;
        SharedPreferences p = getSharedPreferences(Cfg.PREFS, MODE_PRIVATE);
        if (!p.getBoolean(s.chavePref(), true)) return;

        String linha = e.optString("linha", "Linha");
        Status antes = Status.de(e.optString("status_antes", null));
        StringBuilder det = new StringBuilder();
        if (antes != null) det.append("Antes: ").append(antes.icone).append(' ').append(antes.nome);
        juntar(det, limpo(e, "produto"));
        juntar(det, limpo(e, "turno"));
        String hora = limpo(e, "hora");
        if (hora != null && hora.length() >= 5) juntar(det, hora.substring(0, 5));

        Intent abrir = new Intent(this, MainActivity.class).putExtra(MainActivity.EXTRA_OK, true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent piAbrir = PendingIntent.getActivity(this, 10, abrir, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent piOk = PendingIntent.getService(this, 11, new Intent(this, AvisoService.class).setAction(ACAO_OK),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Notification n = new Notification.Builder(this, s.canal())
                .setSmallIcon(R.drawable.ic_stat_logo)
                .setColor(s.cor)
                .setContentTitle(s.icone + " " + linha.toUpperCase() + " — " + s.nome.toUpperCase())
                .setContentText(det.toString())
                .setStyle(new Notification.BigTextStyle().bigText(det.toString()))
                .setCategory(Notification.CATEGORY_ALARM)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setAutoCancel(true)
                .setContentIntent(piAbrir)
                .setDeleteIntent(piOk)
                .addAction(new Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_stat_logo), "OK, VI", piOk).build())
                .build();
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.notify(100 + (linha.hashCode() & 0xFFFF), n);
        tocar(s);
    }

    private static String limpo(JSONObject e, String k) {
        if (e.isNull(k)) return null;
        String v = e.optString(k, "").trim();
        return v.isEmpty() ? null : v;
    }
    private static void juntar(StringBuilder sb, String v) {
        if (v == null) return;
        if (sb.length() > 0) sb.append(" · ");
        sb.append(v);
    }

    void tocar(Status s) {
        pararSom();
        try {
            AudioManager am = getSystemService(AudioManager.class);
            if (volumeAntes < 0) volumeAntes = am.getStreamVolume(AudioManager.STREAM_ALARM);
            am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0);
            AudioAttributes aa = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();
            mp = MediaPlayer.create(this, s.som, aa, am.generateAudioSessionId());
            if (mp == null) { Log.e(TAG, "som não carregou: " + s.nome); return; }
            mp.setOnCompletionListener(m -> { pararSom(); if (repetindo == null) restaurarVolume(); });
            mp.start();
        } catch (Exception e) {
            Log.e(TAG, "erro ao tocar", e);
        }
        if (s.repete) {
            if (repetindo == null) repeteDesde = System.currentTimeMillis();
            repetindo = s;
            h.removeCallbacks(repete);
            h.postDelayed(repete, REPETE_MS);
        }
    }

    private final Runnable repete = new Runnable() {
        @Override public void run() {
            if (repetindo == null) return;
            if (System.currentTimeMillis() - repeteDesde > REPETE_MAX_MS) { pararAlarme(); return; }
            Status s = repetindo;
            pararSom();
            tocar(s);
        }
    };

    private void pararSom() {
        if (mp != null) {
            try { mp.stop(); } catch (Exception ignored) { /* já parou */ }
            mp.release();
            mp = null;
        }
    }

    private void restaurarVolume() {
        if (volumeAntes < 0) return;
        try { getSystemService(AudioManager.class).setStreamVolume(AudioManager.STREAM_ALARM, volumeAntes, 0); }
        catch (Exception ignored) { /* sem acesso ao volume */ }
        volumeAntes = -1;
    }

    void pararAlarme() {
        repetindo = null;
        h.removeCallbacks(repete);
        pararSom();
        restaurarVolume();
    }

    // ── notificações ────────────────────────────────────────────────────────
    private void criarCanais() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        NotificationChannel fixo = new NotificationChannel(CANAL_FIXO, "Avisos ligados", NotificationManager.IMPORTANCE_MIN);
        fixo.setDescription("Mostra que o app está escutando as linhas");
        fixo.setShowBadge(false);
        nm.createNotificationChannel(fixo);
        for (Status s : Status.values()) {
            NotificationChannel c = new NotificationChannel(s.canal(), "Linha em " + s.nome, NotificationManager.IMPORTANCE_HIGH);
            c.setDescription("Quando uma linha muda para " + s.nome);
            c.setSound(null, null);                 // o som é tocado pelo app, no volume de alarme
            c.enableVibration(true);
            c.setVibrationPattern(s.vibra);
            c.enableLights(true);
            c.setLightColor(s.cor);
            c.setBypassDnd(true);
            c.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            nm.createNotificationChannel(c);
        }
    }

    private Notification notifFixa(String texto) {
        PendingIntent pi = PendingIntent.getActivity(this, 1,
                new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this, CANAL_FIXO)
                .setSmallIcon(R.drawable.ic_stat_logo)
                .setColor(0xFF042D4D)
                .setContentTitle("Avisos das linhas")
                .setContentText(texto)
                .setOngoing(true)
                .setContentIntent(pi)
                .build();
    }

    private void atualizarEstado(String texto) {
        estado = texto;
        getSystemService(NotificationManager.class).notify(ID_FIXO, notifFixa(texto));
    }
}
