package br.com.silicate.avisos;

/** Os 4 status do laboratório: cor, ícone, som e se repete até alguém confirmar. */
enum Status {
    OK("OK", "✅", 0xFF16A34A, R.raw.ok, false, new long[]{0, 300, 150, 300}),
    AJUSTE("Ajuste", "⚠️", 0xFFD97706, R.raw.ajuste, false, new long[]{0, 400, 200, 400, 200, 400}),
    MANUTENCAO("Manutenção", "🔧", 0xFF2563EB, R.raw.manutencao, false, new long[]{0, 600, 200, 600, 200, 600}),
    PARADA("Parada", "🛑", 0xFFDC2626, R.raw.parada, true, new long[]{0, 900, 250, 900, 250, 900, 250, 900});

    final String nome, icone;
    final int cor, som;
    final boolean repete;
    final long[] vibra;

    Status(String nome, String icone, int cor, int som, boolean repete, long[] vibra) {
        this.nome = nome; this.icone = icone; this.cor = cor; this.som = som; this.repete = repete; this.vibra = vibra;
    }

    String canal() { return "status_" + name().toLowerCase(); }
    String chavePref() { return "st_" + name(); }

    static Status de(String nome) {
        if (nome == null) return null;
        for (Status s : values()) if (s.nome.equalsIgnoreCase(nome.trim())) return s;
        return null;
    }
}
