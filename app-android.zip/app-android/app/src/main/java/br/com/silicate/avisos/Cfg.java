package br.com.silicate.avisos;

/** Endereços e chave pública (a mesma "anon" do js/supabase.js do ERP — não dá acesso às tabelas). */
final class Cfg {
    static final String SUPABASE = "https://zodgbitbflkepbszshmu.supabase.co";
    static final String ANON = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InpvZGdiaXRiZmxrZXBic3pzaG11Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzYwNjYwNjgsImV4cCI6MjA5MTY0MjA2OH0.iWROA5X7CkxOunt7Cn46wWODa7SQ5nU8OJcD52NhCgA";
    static final String WS = "wss://zodgbitbflkepbszshmu.supabase.co/realtime/v1/websocket?apikey=" + ANON + "&vsn=1.0.0";
    static final String SITE = "https://erp-industrial-theta.vercel.app/";
    static final String ERP = SITE + "dashboard.html";
    static final String PREFS = "avisos";

    private Cfg() {}
}
