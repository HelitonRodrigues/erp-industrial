package br.com.silicate.avisos;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.HttpURLConnection;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Painel de Metas numa TV por DLNA (Samsung, LG, Philips, TCL… "compartilhar mídia").
 *
 * DLNA só mostra ARQUIVO (foto/vídeo), não página. Então o app:
 *  1. abre o painel (painel-metas.html?tv=CÓDIGO) numa WebView invisível e tira uma FOTO dele (JPEG 1920×1080);
 *  2. serve essa foto num servidorzinho HTTP do próprio celular (porta 8077, rede Wi-Fi);
 *  3. manda a TV abrir a foto (UPnP AVTransport: SetAVTransportURI + Play);
 *  4. a cada 5 min tira foto nova e manda de novo.
 * O celular precisa ficar ligado e no MESMO Wi-Fi da TV. Algumas TVs saem da foto sozinhas depois de um tempo —
 * por isso o reenvio periódico.
 */
final class TvDlna {
    static final String TAG = "AvisosTV";
    static final int LARGURA = 1920, ALTURA = 1080, LARGURA_CSS = 1600;
    static final long INTERVALO_MS = 5 * 60_000;
    static final String PREF_CODIGO = "tv_codigo", PREF_NOME = "tv_nome", PREF_CONTROLE = "tv_controle", PREF_ATIVA = "tv_ativa";

    /** TV achada na rede. */
    static final class Tv {
        final String nome, controle;
        Tv(String nome, String controle) { this.nome = nome; this.controle = controle; }
    }

    /** Lido pela tela do app. */
    static volatile String estado = "";
    static volatile boolean ativo = false;

    private final Context ctx;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final HandlerThread rede = new HandlerThread("tv-dlna");
    private final Handler hRede;
    private WebView wv;
    private volatile byte[] foto;
    private volatile int seqFoto = 0;
    private ServerSocket servidor;
    private Thread tServidor;
    private String controle, nome;
    private int carga = 0;
    private WifiManager.WifiLock wifiLock;

    TvDlna(Context ctx) {
        this.ctx = ctx;
        rede.start();
        hRede = new Handler(rede.getLooper());
    }

    // ── liga / desliga ──────────────────────────────────────────────────────
    void iniciar(String nomeTv, String controleTv) {
        parar(false);
        nome = nomeTv; controle = controleTv;
        ativo = true;
        estado = "Preparando o painel para " + nome + "…";
        prefs().edit().putString(PREF_NOME, nome).putString(PREF_CONTROLE, controle).putBoolean(PREF_ATIVA, true).apply();
        try {
            WifiManager wm = (WifiManager) ctx.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "AvisosSilicate:tv");
            wifiLock.setReferenceCounted(false);
            wifiLock.acquire();
        } catch (Exception e) { Log.w(TAG, "sem wifi lock", e); }
        hRede.post(this::ligarServidor);
        main.post(ciclo);
    }

    /** @param esquecer true = a pessoa mandou parar (não volta sozinho depois de reiniciar). */
    void parar(boolean esquecer) {
        ativo = false;
        main.removeCallbacks(ciclo);
        carga++;
        if (esquecer) {
            prefs().edit().putBoolean(PREF_ATIVA, false).apply();
            final String c = controle;
            if (c != null) hRede.post(() -> { try { soap(c, "Stop", "<InstanceID>0</InstanceID>"); } catch (Exception ignored) { /* TV já fora */ } });
            estado = "";
        }
        if (wifiLock != null && wifiLock.isHeld()) wifiLock.release();
        hRede.post(this::desligarServidor);
        if (wv != null) { final WebView w = wv; wv = null; main.post(w::destroy); }
    }

    /** Volta a passar na TV depois de o celular reiniciar, se estava ligado. */
    void retomarSeEstavaLigado() {
        SharedPreferences p = prefs();
        if (p.getBoolean(PREF_ATIVA, false) && p.getString(PREF_CONTROLE, null) != null && !p.getString(PREF_CODIGO, "").isEmpty()) {
            iniciar(p.getString(PREF_NOME, "TV"), p.getString(PREF_CONTROLE, null));
        }
    }

    void mandarAgora() {
        if (!ativo) return;
        main.removeCallbacks(ciclo);
        main.post(ciclo);
    }

    private SharedPreferences prefs() { return ctx.getSharedPreferences(Cfg.PREFS, Context.MODE_PRIVATE); }

    // ── ciclo: foto do painel → manda para a TV → espera 5 min ─────────────
    private final Runnable ciclo = new Runnable() {
        @Override public void run() {
            if (!ativo) return;
            fotografarPainel();
            main.postDelayed(this, INTERVALO_MS);
        }
    };

    private void fotografarPainel() {
        String codigo = prefs().getString(PREF_CODIGO, "");
        if (codigo.isEmpty()) { estado = "Falta o código da TV (aparece no ERP em “Passar para a TV”)."; return; }
        if (wv == null) {
            WebView.enableSlowWholeDocumentDraw();
            wv = new WebView(ctx);
            WebSettings s = wv.getSettings();
            s.setJavaScriptEnabled(true);
            s.setDomStorageEnabled(true);
            s.setUseWideViewPort(true);
            s.setLoadWithOverviewMode(true);
            wv.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            wv.measure(View.MeasureSpec.makeMeasureSpec(LARGURA, View.MeasureSpec.EXACTLY),
                       View.MeasureSpec.makeMeasureSpec(ALTURA, View.MeasureSpec.EXACTLY));
            wv.layout(0, 0, LARGURA, ALTURA);
        }
        final int minha = ++carga;
        wv.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView v, String url) {
                if (minha == carga) esperarPronto(minha, 0);
            }
        });
        try { wv.onResume(); wv.resumeTimers(); } catch (Exception ignored) { }
        String url = Cfg.SITE + "painel-metas.html?tv=" + codigo + "&largura=" + LARGURA_CSS + "&captura=1&t=" + System.currentTimeMillis();
        wv.loadUrl(url);
    }

    /** O painel avisa quando terminou de desenhar (window.__painelPronto). Espera até 25 s. */
    private void esperarPronto(int minha, int tentativa) {
        if (minha != carga || wv == null) return;
        wv.evaluateJavascript("(window.__painelPronto||0)+'|'+(window.__painelErro||'')", valor -> {
            String v = valor == null ? "" : valor.replace("\"", "");
            String[] partes = v.split("\\|", -1);
            boolean pronto = partes.length > 0 && !partes[0].equals("0") && !partes[0].isEmpty();
            String erro = partes.length > 1 ? partes[1] : "";
            if (!erro.isEmpty()) { estado = "⚠️ " + erro; main.removeCallbacks(ciclo); if (ativo) main.postDelayed(ciclo, 60_000); return; }
            if (pronto || tentativa >= 50) main.postDelayed(() -> capturar(minha), 1200);   // deixa as fontes assentarem
            else main.postDelayed(() -> esperarPronto(minha, tentativa + 1), 500);
        });
    }

    private void capturar(int minha) {
        if (minha != carga || wv == null) return;
        try {
            wv.measure(View.MeasureSpec.makeMeasureSpec(LARGURA, View.MeasureSpec.EXACTLY),
                       View.MeasureSpec.makeMeasureSpec(ALTURA, View.MeasureSpec.EXACTLY));
            wv.layout(0, 0, LARGURA, ALTURA);
            Bitmap bmp = Bitmap.createBitmap(LARGURA, ALTURA, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(bmp);
            c.drawColor(0xFFEEF2F6);
            wv.draw(c);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            bmp.compress(Bitmap.CompressFormat.JPEG, 88, out);
            bmp.recycle();
            foto = out.toByteArray();
            seqFoto++;
            final int n = seqFoto;
            hRede.post(() -> enviarParaTv(n));
        } catch (Exception e) {
            Log.e(TAG, "foto do painel", e);
            estado = "⚠️ Não consegui tirar a foto do painel.";
        }
    }

    // ── manda a foto para a TV (UPnP AVTransport) ───────────────────────────
    private void enviarParaTv(int n) {
        String ip = ipWifi();
        if (ip == null) { estado = "⚠️ O celular não está no Wi-Fi."; return; }
        if (servidor == null) ligarServidor();
        if (servidor == null) { estado = "⚠️ Não consegui abrir a porta no celular."; return; }
        String url = "http://" + ip + ":" + servidor.getLocalPort() + "/painel-" + n + ".jpg";
        String didl = "<DIDL-Lite xmlns=\"urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/\" xmlns:dc=\"http://purl.org/dc/elements/1.1/\" "
                + "xmlns:upnp=\"urn:schemas-upnp-org:metadata-1-0/upnp/\"><item id=\"painel" + n + "\" parentID=\"0\" restricted=\"1\">"
                + "<dc:title>Metas das Linhas</dc:title><upnp:class>object.item.imageItem.photo</upnp:class>"
                + "<res protocolInfo=\"http-get:*:image/jpeg:DLNA.ORG_PN=JPEG_LRG;DLNA.ORG_OP=01;DLNA.ORG_FLAGS=00900000000000000000000000000000\" "
                + "resolution=\"" + LARGURA + "x" + ALTURA + "\">" + url + "</res></item></DIDL-Lite>";
        try {
            tocar(url, didl);
            estado = "📺 Passando em " + nome + " · atualizado às " + agora();
        } catch (Exception e) {
            Log.w(TAG, "TV não respondeu; procurando de novo", e);
            // A TV pode ter sido desligada/ligada, mudado de IP ou de porta: acha de novo pelo nome
            try {
                Tv nova = reencontrar();
                if (nova != null) {
                    controle = nova.controle;
                    prefs().edit().putString(PREF_CONTROLE, controle).apply();
                    tocar(url, didl);
                    estado = "📺 Passando em " + nome + " · atualizado às " + agora() + " (reconectou sozinho)";
                    return;
                }
            } catch (Exception e2) { Log.e(TAG, "reconectar TV", e2); }
            estado = "⚠️ A TV " + nome + " não respondeu às " + agora() + ". Tento de novo em 1 minuto (ela está ligada e no mesmo Wi-Fi?)";
            main.removeCallbacks(ciclo);
            if (ativo) main.postDelayed(ciclo, 60_000);
        }
    }

    private void tocar(String url, String didl) throws IOException {
        try { soap(controle, "Stop", "<InstanceID>0</InstanceID>"); } catch (Exception ignored) { /* algumas TVs reclamam se nada tocava */ }
        soap(controle, "SetAVTransportURI", "<InstanceID>0</InstanceID><CurrentURI>" + xml(url) + "</CurrentURI><CurrentURIMetaData>" + xml(didl) + "</CurrentURIMetaData>");
        soap(controle, "Play", "<InstanceID>0</InstanceID><Speed>1</Speed>");
    }

    /** Procura as TVs de novo e devolve a de mesmo nome (ou a única que houver). */
    private Tv reencontrar() throws IOException {
        List<Tv> tvs = procurar(ctx);
        for (Tv t : tvs) if (t.nome != null && t.nome.equals(nome)) return t;
        return tvs.size() == 1 ? tvs.get(0) : null;
    }

    private static String agora() {
        return new java.text.SimpleDateFormat("HH:mm", new Locale("pt", "BR")).format(new java.util.Date());
    }

    static void soap(String controle, String acao, String args) throws IOException {
        String corpo = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"
                + "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">"
                + "<s:Body><u:" + acao + " xmlns:u=\"urn:schemas-upnp-org:service:AVTransport:1\">" + args + "</u:" + acao + "></s:Body></s:Envelope>";
        HttpURLConnection c = (HttpURLConnection) new URL(controle).openConnection();
        c.setConnectTimeout(4000);
        c.setReadTimeout(6000);
        c.setRequestMethod("POST");
        c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "text/xml; charset=\"utf-8\"");
        c.setRequestProperty("SOAPACTION", "\"urn:schemas-upnp-org:service:AVTransport:1#" + acao + "\"");
        byte[] b = corpo.getBytes(StandardCharsets.UTF_8);
        c.setFixedLengthStreamingMode(b.length);
        try (OutputStream o = c.getOutputStream()) { o.write(b); }
        int code = c.getResponseCode();
        if (code >= 300) {
            String err = ler(c.getErrorStream());
            Matcher m = Pattern.compile("<errorDescription>(.*?)</errorDescription>", Pattern.DOTALL).matcher(err == null ? "" : err);
            throw new IOException(acao + " " + code + (m.find() ? " " + m.group(1) : ""));
        }
        ler(c.getInputStream());
        c.disconnect();
    }

    private static String xml(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }

    // ── servidorzinho HTTP que entrega a foto para a TV ────────────────────
    private void ligarServidor() {
        if (servidor != null) return;
        try {
            ServerSocket s;
            try { s = new ServerSocket(8077); } catch (IOException ocupada) { s = new ServerSocket(0); }
            servidor = s;
            final ServerSocket ss = s;
            tServidor = new Thread(() -> {
                while (!ss.isClosed()) {
                    try {
                        final Socket cli = ss.accept();
                        new Thread(() -> atender(cli), "tv-foto").start();
                    } catch (IOException e) { if (!ss.isClosed()) Log.w(TAG, "accept", e); }
                }
            }, "tv-servidor");
            tServidor.start();
        } catch (IOException e) {
            Log.e(TAG, "servidor", e);
        }
    }

    private void desligarServidor() {
        try { if (servidor != null) servidor.close(); } catch (IOException ignored) { /* já fechado */ }
        servidor = null;
    }

    private void atender(Socket cli) {
        try (Socket s = cli) {
            s.setSoTimeout(10_000);
            InputStream in = s.getInputStream();
            StringBuilder cab = new StringBuilder();
            int ch, fim = 0;
            while ((ch = in.read()) != -1 && cab.length() < 8192) {
                cab.append((char) ch);
                fim = (ch == '\r' || ch == '\n') ? fim + 1 : 0;
                if (fim >= 4) break;
            }
            String primeira = cab.toString().split("\r\n", 2)[0];
            boolean head = primeira.startsWith("HEAD");
            byte[] f = foto;
            OutputStream out = s.getOutputStream();
            if (f == null) {
                out.write("HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\nConnection: close\r\n\r\n".getBytes(StandardCharsets.US_ASCII));
                return;
            }
            String h = "HTTP/1.1 200 OK\r\nContent-Type: image/jpeg\r\nContent-Length: " + f.length + "\r\n"
                    + "transferMode.dlna.org: Interactive\r\n"
                    + "contentFeatures.dlna.org: DLNA.ORG_PN=JPEG_LRG;DLNA.ORG_OP=01;DLNA.ORG_FLAGS=00900000000000000000000000000000\r\n"
                    + "Cache-Control: no-cache\r\nConnection: close\r\n\r\n";
            out.write(h.getBytes(StandardCharsets.US_ASCII));
            if (!head) out.write(f);
            out.flush();
        } catch (IOException e) {
            Log.w(TAG, "atender", e);
        }
    }

    // ── procurar TVs na rede (SSDP) ─────────────────────────────────────────
    /** Bloqueia ~4 s. Chamar fora da thread principal. */
    static List<Tv> procurar(Context ctx) throws IOException {
        WifiManager wm = (WifiManager) ctx.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        WifiManager.MulticastLock trava = wm.createMulticastLock("AvisosSilicate:ssdp");
        trava.setReferenceCounted(false);
        trava.acquire();
        Map<String, Boolean> locais = new LinkedHashMap<>();
        try (DatagramSocket s = new DatagramSocket()) {
            s.setSoTimeout(400);
            InetAddress grupo = InetAddress.getByName("239.255.255.250");
            String[] tipos = {"urn:schemas-upnp-org:device:MediaRenderer:1", "urn:schemas-upnp-org:service:AVTransport:1"};
            for (int volta = 0; volta < 2; volta++) {
                for (String st : tipos) {
                    byte[] b = ("M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: \"ssdp:discover\"\r\nMX: 2\r\nST: " + st + "\r\n\r\n")
                            .getBytes(StandardCharsets.US_ASCII);
                    s.send(new DatagramPacket(b, b.length, grupo, 1900));
                }
            }
            long ate = System.currentTimeMillis() + 3500;
            byte[] buf = new byte[4096];
            while (System.currentTimeMillis() < ate) {
                DatagramPacket p = new DatagramPacket(buf, buf.length);
                try { s.receive(p); } catch (SocketTimeoutException t) { continue; }
                String r = new String(p.getData(), 0, p.getLength(), StandardCharsets.UTF_8);
                Matcher m = Pattern.compile("(?im)^location:\\s*(\\S+)").matcher(r);
                if (m.find()) locais.put(m.group(1).trim(), true);
            }
        } finally {
            trava.release();
        }
        List<Tv> tvs = new ArrayList<>();
        for (String loc : locais.keySet()) {
            try {
                Tv tv = lerDescricao(loc);
                if (tv != null) tvs.add(tv);
            } catch (Exception e) { Log.w(TAG, "descrição " + loc, e); }
        }
        return tvs;
    }

    private static Tv lerDescricao(String local) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(local).openConnection();
        c.setConnectTimeout(3000);
        c.setReadTimeout(4000);
        String x = ler(c.getInputStream());
        c.disconnect();
        if (x == null) return null;
        String nome = tag(x, "friendlyName");
        String base = tag(x, "URLBase");
        Matcher sv = Pattern.compile("<service>(.*?)</service>", Pattern.DOTALL).matcher(x);
        while (sv.find()) {
            String bloco = sv.group(1);
            String tipo = tag(bloco, "serviceType");
            if (tipo != null && tipo.contains("AVTransport")) {
                String ctrl = tag(bloco, "controlURL");
                if (ctrl == null) continue;
                String controle = new URL(new URL(base != null && !base.isEmpty() ? base : local), ctrl.trim()).toString();
                return new Tv(nome != null ? nome.trim() : new URL(local).getHost(), controle);
            }
        }
        return null;
    }

    private static String tag(String xml, String nome) {
        Matcher m = Pattern.compile("<(?:\\w+:)?" + nome + "[^>]*>(.*?)</(?:\\w+:)?" + nome + ">", Pattern.DOTALL).matcher(xml);
        return m.find() ? m.group(1).replace("&amp;", "&") : null;
    }

    private static String ler(InputStream in) throws IOException {
        if (in == null) return null;
        try (InputStream i = in) {
            ByteArrayOutputStream o = new ByteArrayOutputStream();
            byte[] b = new byte[8192];
            int n;
            while ((n = i.read(b)) > 0) o.write(b, 0, n);
            return o.toString("UTF-8");
        }
    }

    /** IP do celular no Wi-Fi (é o endereço que a TV usa para buscar a foto). */
    static String ipWifi() {
        try {
            List<NetworkInterface> ifs = Collections.list(NetworkInterface.getNetworkInterfaces());
            String reserva = null;
            for (NetworkInterface ni : ifs) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (!(a instanceof Inet4Address) || a.isLoopbackAddress()) continue;
                    String ip = a.getHostAddress();
                    if (ni.getName().startsWith("wlan")) return ip;
                    if (reserva == null || (a.isSiteLocalAddress() && !reserva.startsWith("192.168.") && !reserva.startsWith("10."))) reserva = ip;
                }
            }
            return reserva;
        } catch (Exception e) {
            return null;
        }
    }
}
