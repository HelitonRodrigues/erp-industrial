package br.com.silicate.avisos;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Liga os avisos sozinho quando o celular reinicia ou o app é atualizado. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent intent) {
        String a = intent != null ? intent.getAction() : null;
        if (Intent.ACTION_BOOT_COMPLETED.equals(a) || Intent.ACTION_MY_PACKAGE_REPLACED.equals(a)) {
            try {
                ctx.startForegroundService(new Intent(ctx, AvisoService.class));
            } catch (Exception e) {
                android.util.Log.e("Avisos", "não ligou no boot", e);
            }
        }
    }
}
